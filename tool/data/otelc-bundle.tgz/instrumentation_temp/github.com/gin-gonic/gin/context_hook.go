// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package server

import (
	"github.com/gin-gonic/gin"
	"go.opentelemetry.io/otel/codes"
	semconv "go.opentelemetry.io/otel/semconv/v1.37.0"
	"go.opentelemetry.io/otel/trace"

	httpsemconv "go.opentelemetry.io/otelc/instrumentation/net/http/semconv"
	"go.opentelemetry.io/otelc/pkg/hook"
)

// routeSetKey is stored on the gin.Context to prevent repeated span updates
// when multiple middleware layers call c.Next(). The key is reserved by this
// package; user middleware must not set or read it.
const (
	routeSetKey  = "otel.gin.route.set"
	nextDepthKey = "otel.gin.next.depth"
)

// enabledDataKey stores BeforeNext's enabler.Enable() result on the hook
// context so AfterNext can reuse it instead of re-reading it. BeforeNext and
// AfterNext share one hook context per (*gin.Context).Next call, so this
// keeps the pair's gating decision consistent even if the environment
// variable changes while the call is in flight.
const enabledDataKey = "otel.gin.enabled"

// BeforeNext runs before (*gin.Context).Next. By the time Next is called,
// gin's router has already matched the request to a route and populated
// c.FullPath(). We use this to update the span name from the initial
// "METHOD" to "METHOD /route/pattern" and record the http.route attribute.
func BeforeNext(ictx hook.HookContext, c *gin.Context) {
	// Next is called once per middleware in the chain, so this runs several
	// times per request. Keep the disabled path free of logging.
	enabled := enabler.Enable()
	ictx.SetKeyData(enabledDataKey, enabled)
	if !enabled {
		return
	}

	if c == nil || c.Request == nil {
		return
	}

	if d, exists := c.Get(nextDepthKey); exists {
		if depth, ok := d.(int); ok {
			c.Set(nextDepthKey, depth+1)
		} else {
			c.Set(nextDepthKey, 1)
		}
	} else {
		c.Set(nextDepthKey, 1)
	}

	route := c.FullPath()
	if route == "" {
		// No route matched (e.g. 404). Leave the span name as the method only.
		return
	}

	// c.Next() is called by each middleware in the chain, so this hook fires
	// multiple times per request. Only the first call needs to update the span.
	if _, already := c.Get(routeSetKey); already {
		return
	}

	span := trace.SpanFromContext(c.Request.Context())
	if !span.IsRecording() {
		return
	}

	// Set the gate only after confirming we have a recording span to update.
	// Otherwise a non-recording first call would burn the gate and block a
	// later recording span on the same request from being enriched.
	c.Set(routeSetKey, struct{}{})

	span.SetName(httpsemconv.HTTPServerSpanName(c.Request.Method, route))
	span.SetAttributes(semconv.HTTPRouteKey.String(route))

	logger.Debug("gin route resolved", "route", route)
}

// AfterNext runs after (*gin.Context).Next returns. It records any errors
// accumulated via c.Error() during request handling.
func AfterNext(ictx hook.HookContext) {
	// Reuse BeforeNext's gating decision so this pair stays balanced against
	// nextDepthKey even if the environment variable changes mid-call.
	enabled, _ := ictx.GetKeyData(enabledDataKey).(bool)
	if !enabled {
		return
	}

	c, ok := ictx.GetParam(0).(*gin.Context)
	if !ok || c == nil || c.Request == nil {
		return
	}

	d, _ := c.Get(nextDepthKey)
	depth, _ := d.(int)
	depth--
	c.Set(nextDepthKey, depth)

	if depth > 0 {
		return
	}

	if len(c.Errors) == 0 {
		return
	}

	span := trace.SpanFromContext(c.Request.Context())
	if !span.IsRecording() {
		return
	}

	span.SetStatus(codes.Error, c.Errors.String())
	for _, e := range c.Errors {
		span.RecordError(e.Err)
	}
}
